function e = eenxk(x,k)

e=eenxkm(x,k)+1;

end
